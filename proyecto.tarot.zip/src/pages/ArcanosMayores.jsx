import Cartas from "../components/Cartas";

function Arcanos() {
  return (
    <div>
      <Cartas />
    </div>
  );
}

export default Arcanos;
