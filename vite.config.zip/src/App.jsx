import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import ArcanosMayores from "./pages/ArcanosMayores";
import ArcanosMenores from "./pages/ArcanosMenores";
import Lecturas from "./pages/Lecturas";

function App() {
  return (
    <Router>
      <nav style={{ padding: "12px 0", display: "flex", gap: "12px" }}>
        <Link to="/">Inicio</Link>
        <Link to="/arcanos-mayores">Arcanos Mayores</Link>
        <Link to="/arcanos-menores">Arcanos Menores</Link>
        <Link to="/lecturas">Lecturas</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/arcanos-mayores" element={<ArcanosMayores />} />
        <Route path="/arcanos-menores" element={<ArcanosMenores />} />
        <Route path="/lecturas" element={<Lecturas />} />
      </Routes>
    </Router>
  );
}

export default App;
