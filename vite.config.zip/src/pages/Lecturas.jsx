function Lecturas() {
  return (
    <div className="container py-4">
      <h1>Lecturas de Tarot</h1>
      <p>Aquí podrás realizar diferentes tiradas con los arcanos.</p>
      {/* más adelante agregamos lógica de tiradas */}
    </div>
  );
}

export default Lecturas;
