function Menores() {
  return (
    <div className="container py-4">
      <h1>Arcanos Menores</h1>
      <p>Pronto estarán disponibles los 56 Arcanos Menores.</p>
      {/* aquí después mostramos cartas menores */}
    </div>
  );
}

export default Menores;
