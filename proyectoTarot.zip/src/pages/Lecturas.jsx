import React, { useState } from "react";
import { interpretarConBackend } from "../services/tarotApi";

export default function Lecturas() {
  const [pregunta, setPregunta] = useState("");
  const [respuesta, setRespuesta] = useState("");
  const [cargando, setCargando] = useState(false);

  const handleInterpretar = async () => {
    try {
      setCargando(true);
      const texto = await interpretarConBackend(pregunta, "El Loco"); 
      setRespuesta(texto);
    } catch (error) {
      console.error(error);
      setRespuesta("Hubo un error al conectar con el backend 😢");
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="container py-4">
      <h1>Lecturas con Backend</h1>

      <input
        type="text"
        className="form-control mb-3"
        placeholder="Escribe tu pregunta..."
        value={pregunta}
        onChange={(e) => setPregunta(e.target.value)}
      />

      <button
        className="btn btn-primary mb-3"
        onClick={handleInterpretar}
        disabled={cargando}
      >
        {cargando ? "Consultando..." : "Interpretar"}
      </button>

      {respuesta && (
        <div className="card p-3">
          <h5>Interpretación:</h5>
          <p>{respuesta}</p>
        </div>
      )}
    </div>
  );
}
